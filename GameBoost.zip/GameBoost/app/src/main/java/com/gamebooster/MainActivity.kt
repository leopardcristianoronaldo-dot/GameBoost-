package com.gamebooster

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private val voice = VoiceChanger()
    private lateinit var ramTile: Tile
    private lateinit var batTile: Tile
    private lateinit var gpuTile: Tile
    private lateinit var tip: TextView
    private lateinit var gamesBox: LinearLayout
    private lateinit var overlayBtn: TextView
    private lateinit var voiceBtn: TextView
    private val chips = ArrayList<TextView>()
    private val presets = listOf(
        "Normal" to 1.0f, "Berat" to 0.7f, "Tinggi" to 1.35f, "Imut" to 1.8f
    )

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        val c = this

        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(c, 16), Ui.dp(c, 24), Ui.dp(c, 16), Ui.dp(c, 32))
        }
        root.addView(Ui.text(c, "GameBoost", 30f, Ui.TEXT, true))
        root.addView(Ui.text(c, "Ruang game kamu", 13f, Ui.DIM))

        // --- Performa ---
        val status = Ui.card(c)
        status.addView(Ui.text(c, "PERFORMA", 11f, Ui.DIM, true))
        ramTile = Ui.tile(c, "RAM KOSONG")
        batTile = Ui.tile(c, "SUHU BATERAI")
        gpuTile = Ui.tile(c, "SUHU GPU")
        val tiles = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                topMargin = Ui.dp(c, 10)
            }
        }
        tiles.addView(ramTile.root)
        tiles.addView(batTile.root)
        tiles.addView(gpuTile.root)
        status.addView(tiles)
        tip = Ui.text(c, "", 13f, Ui.DIM)
        tip.setPadding(0, Ui.dp(c, 10), 0, 0)
        status.addView(tip)
        root.addView(status)

        // --- Game ---
        val games = Ui.card(c)
        games.addView(Ui.text(c, "GAME SAYA", 11f, Ui.DIM, true))
        gamesBox = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        games.addView(gamesBox)
        games.addView(Ui.text(c, "Ketuk game untuk Boost & Main. Tekan lama untuk menghapus.", 12f, Ui.DIM))
        root.addView(games)

        // --- Mode game ---
        val mode = Ui.card(c)
        mode.addView(Ui.text(c, "MODE GAME", 11f, Ui.DIM, true))
        mode.addView(
            Ui.switchRow(
                c, "Overlay otomatis", "Tampilkan FPS & suhu saat membuka game",
                Store.flag(c, Store.AUTO, true)
            ) { on -> Store.setFlag(c, Store.AUTO, on) }
        )
        mode.addView(
            Ui.switchRow(
                c, "Mode Fokus", "Jangan Ganggu (prioritas) selama overlay aktif",
                Store.flag(c, Store.DND, false)
            ) { on ->
                Store.setFlag(c, Store.DND, on)
                if (on && !Booster.hasDnd(c)) {
                    Toast.makeText(c, "Izinkan akses Jangan Ganggu untuk GameBoost", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                }
            }
        )
        overlayBtn = Ui.button(c, "Nyalakan Overlay", Ui.ALT) { toggleOverlay() }
        mode.addView(overlayBtn)
        mode.addView(Ui.button(c, "Bersihkan RAM", Ui.ALT) { clean() })
        mode.addView(Ui.button(c, "Pilih App Multitasking (maks. 5)", Ui.ALT) { pickPins() })
        mode.addView(Ui.text(c, "Ketuk overlay untuk membuka panel multitasking.", 12f, Ui.DIM))
        root.addView(mode)

        // --- Pengubah suara ---
        val vc = Ui.card(c)
        vc.addView(Ui.text(c, "PENGUBAH SUARA", 11f, Ui.DIM, true))
        val chipRow = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                topMargin = Ui.dp(c, 10)
            }
        }
        presets.forEachIndexed { i, p ->
            val chip = Ui.chip(c, p.first, i == 0) { selectPreset(i) }
            chips.add(chip)
            chipRow.addView(chip)
        }
        vc.addView(chipRow)
        voiceBtn = Ui.button(c, "Mulai Pengubah Suara") { toggleVoice() }
        vc.addView(voiceBtn)
        vc.addView(Ui.text(c, "Pakai headset agar tidak ada gema. Hanya berlaku di app ini.", 12f, Ui.DIM))
        root.addView(vc)

        setContentView(ScrollView(c).apply {
            setBackgroundColor(Ui.BG)
            fitsSystemWindows = true
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        // Jika proses sempat mati saat Mode Fokus aktif, kembalikan pengaturan Jangan Ganggu.
        if (!OverlayService.running) Booster.setDnd(this, false)
        renderGames()
        h.post(tick)
    }

    override fun onPause() {
        h.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        voice.stop()
        super.onDestroy()
    }

    private fun tipFor(b: Booster.Batt, availMb: Long): String = when {
        b.temp >= 43f -> "HP terlalu panas. Istirahat sebentar, turunkan kecerahan, dan lepas casing."
        b.temp >= 40f && b.charging -> "HP hangat sambil mengisi daya. Cabut charger saat main agar suhu turun."
        availMb < 600 -> "RAM menipis. Ketuk Bersihkan RAM sebelum main."
        b.pct in 0..15 && !b.charging -> "Baterai tinggal ${b.pct}%. Colok charger sebelum main lama."
        else -> "Kondisi bagus, siap main."
    }

    private fun refresh() {
        val c = this
        val total = Booster.totalMb(c).coerceAtLeast(1L)
        val avail = Booster.availMb(c)
        val free = avail.toFloat() / total
        ramTile.value.text = "$avail MB"
        ramTile.bar.fraction = free
        ramTile.bar.color = if (free < 0.15f) Ui.BAD else if (free < 0.3f) Ui.WARN else Ui.ACCENT

        val b = Booster.battery(c)
        batTile.value.text = "${"%.1f".format(b.temp)}°C"
        batTile.bar.fraction = b.temp / 60f
        batTile.bar.color = Ui.heat(b.temp)

        val g = Booster.gpuTemp()
        if (g != null) {
            gpuTile.value.text = "${g.toInt()}°C"
            gpuTile.bar.fraction = g / 90f
            gpuTile.bar.color = Ui.heat(g)
        } else {
            gpuTile.value.text = "n/a"
            gpuTile.bar.fraction = 0f
        }

        tip.text = tipFor(b, avail)
        overlayBtn.text = if (OverlayService.running) "Matikan Overlay" else "Nyalakan Overlay"
        voiceBtn.text = if (voice.active) "Stop Pengubah Suara" else "Mulai Pengubah Suara"
    }

    // ---------- Daftar game ----------

    private fun renderGames() {
        val c = this
        val pm = packageManager
        gamesBox.removeAllViews()
        val games = Store.getList(c, Store.GAMES).filter { pm.getLaunchIntentForPackage(it) != null }
        val cells = ArrayList<View>()
        for (p in games) cells.add(gameCell(p))
        cells.add(addCell())
        var i = 0
        while (i < cells.size) {
            val row = LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                    topMargin = Ui.dp(c, 8)
                }
            }
            for (k in 0 until 4) {
                val v = if (i + k < cells.size) {
                    cells[i + k]
                } else {
                    View(c).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) }
                }
                row.addView(v)
            }
            gamesBox.addView(row)
            i += 4
        }
    }

    private fun cell(icon: View, label: String): LinearLayout {
        val c = this
        val box = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(Ui.dp(c, 2), Ui.dp(c, 4), Ui.dp(c, 2), Ui.dp(c, 4))
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        }
        val name = Ui.text(c, label, 11f, Ui.TEXT).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                topMargin = Ui.dp(c, 4)
            }
        }
        box.addView(icon)
        box.addView(name)
        return box
    }

    private fun gameCell(pkg: String): View {
        val c = this
        val pm = packageManager
        val label = try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        val iv = ImageView(c).apply {
            try { setImageDrawable(pm.getApplicationIcon(pkg)) } catch (e: Exception) { }
            layoutParams = LinearLayout.LayoutParams(Ui.dp(c, 52), Ui.dp(c, 52))
        }
        val box = cell(iv, label)
        box.setOnClickListener { play(pkg) }
        box.setOnLongClickListener {
            AlertDialog.Builder(c)
                .setTitle("Hapus dari daftar?")
                .setMessage(label)
                .setPositiveButton("Hapus") { _, _ ->
                    val l = Store.getList(c, Store.GAMES)
                    l.remove(pkg)
                    Store.putList(c, Store.GAMES, l)
                    renderGames()
                }
                .setNegativeButton("Batal", null)
                .show()
            true
        }
        return box
    }

    private fun addCell(): View {
        val c = this
        val plus = TextView(c).apply {
            text = "+"
            textSize = 26f
            setTextColor(Ui.TEXT)
            gravity = Gravity.CENTER
            background = Ui.bg(Ui.ALT, 14, c)
            layoutParams = LinearLayout.LayoutParams(Ui.dp(c, 52), Ui.dp(c, 52))
        }
        val box = cell(plus, "Tambah")
        box.setOnClickListener { pickGames() }
        return box
    }

    private fun pickGames() {
        val c = this
        val pm = packageManager
        val apps = Booster.launcherApps(c)
        val pk = apps.map { it.activityInfo.packageName }
        val names = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        val sel = Store.getList(c, Store.GAMES)
        val checked = BooleanArray(pk.size) { pk[it] in sel }
        AlertDialog.Builder(c)
            .setTitle("Tambah game")
            .setMultiChoiceItems(names, checked) { _, i, on ->
                if (on) {
                    if (pk[i] !in sel) sel.add(pk[i])
                } else {
                    sel.remove(pk[i])
                }
            }
            .setPositiveButton("Simpan") { _, _ ->
                Store.putList(c, Store.GAMES, sel)
                renderGames()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun pickPins() {
        val c = this
        val pm = packageManager
        val apps = Booster.launcherApps(c)
        val pk = apps.map { it.activityInfo.packageName }
        val names = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        val sel = Store.getList(c, Store.PINS)
        val checked = BooleanArray(pk.size) { pk[it] in sel }
        AlertDialog.Builder(c)
            .setTitle("App multitasking (maks. 5)")
            .setMultiChoiceItems(names, checked) { _, i, on ->
                if (on) {
                    if (pk[i] !in sel) sel.add(pk[i])
                } else {
                    sel.remove(pk[i])
                }
            }
            .setPositiveButton("Simpan") { _, _ ->
                if (sel.size > 5) {
                    Toast.makeText(c, "Hanya 5 app pertama yang disimpan", Toast.LENGTH_SHORT).show()
                }
                Store.putList(c, Store.PINS, sel.take(5))
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- Aksi ----------

    private fun clean() {
        val c = this
        val before = Booster.availMb(c)
        Booster.cleanRam(c) {
            Toast.makeText(c, "RAM kosong: $before → ${Booster.availMb(c)} MB", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startOverlay(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan 'Tampil di atas app lain', lalu coba lagi", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        return true
    }

    private fun toggleOverlay() {
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
        } else {
            startOverlay()
        }
    }

    private fun play(pkg: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch == null) {
            Toast.makeText(this, "Game tidak ditemukan", Toast.LENGTH_SHORT).show()
            return
        }
        if (Store.flag(this, Store.AUTO, true) && !OverlayService.running && !startOverlay()) return
        Booster.cleanRam(this, listOf(pkg))
        startActivity(launch)
    }

    private fun selectPreset(i: Int) {
        voice.pitch = presets[i].second
        chips.forEachIndexed { k, v ->
            v.background = Ui.bg(if (k == i) Ui.ACCENT else Ui.ALT, 20, this)
        }
    }

    private fun toggleVoice() {
        if (voice.active) {
            voice.stop()
            refresh()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            return
        }
        voice.start()
        refresh()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 2 && res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) toggleVoice()
    }
}
