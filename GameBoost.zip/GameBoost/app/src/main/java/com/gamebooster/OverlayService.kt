package com.gamebooster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {
    companion object {
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var fpsTv: TextView
    private lateinit var gpuTv: TextView
    private lateinit var batTv: TextView
    private lateinit var ramTv: TextView
    private lateinit var timeTv: TextView
    private lateinit var lp: WindowManager.LayoutParams
    private val h = Handler(Looper.getMainLooper())
    private var frames = 0
    private var startedAt = 0L

    // Menghitung frame UI per detik (BUKAN FPS game lain).
    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames++
            if (running) Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            val c = this@OverlayService
            val fps = frames
            frames = 0
            fpsTv.text = "FPS $fps"
            fpsTv.setTextColor(if (fps >= 50) Ui.GOOD else if (fps >= 30) Ui.WARN else Ui.BAD)

            val g = Booster.gpuTemp()
            if (g != null) {
                gpuTv.visibility = View.VISIBLE
                gpuTv.text = "GPU ${g.toInt()}°"
                gpuTv.setTextColor(Ui.heat(g))
            } else {
                gpuTv.visibility = View.GONE
            }

            val b = Booster.battery(c)
            batTv.text = "BAT ${b.temp.toInt()}°"
            batTv.setTextColor(Ui.heat(b.temp))
            ramTv.text = "RAM ${"%.1f".format(Booster.availMb(c) / 1024f)}G"

            if (panel.visibility == View.VISIBLE) {
                val s = (SystemClock.elapsedRealtime() - startedAt) / 1000
                timeTv.text = "Durasi main  %02d:%02d".format(s / 60, s % 60)
            }
            h.postDelayed(this, 1000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        startedAt = SystemClock.elapsedRealtime()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startFg()
        try {
            buildOverlay()
        } catch (e: Exception) {
            stopSelf()
            return
        }
        if (Store.flag(this, Store.DND, false)) Booster.setDnd(this, true)
        Choreographer.getInstance().postFrameCallback(frameCb)
        h.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_NOT_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        h.removeCallbacks(tick)
        Choreographer.getInstance().removeFrameCallback(frameCb)
        try { wm.removeView(root) } catch (e: Exception) { }
        Booster.setDnd(this, false)
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("gb", "GameBoost", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "gb")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("GameBoost aktif")
            .setContentText("Overlay monitor berjalan")
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun metric(): TextView {
        val c = this
        return Ui.text(c, "--", 12f, Ui.TEXT, true).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = Ui.dp(c, 10) }
        }
    }

    private fun buildOverlay() {
        val c = this
        root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.bg(Color.parseColor("#E6141720"), 14, c)
            setPadding(Ui.dp(c, 12), Ui.dp(c, 8), Ui.dp(c, 6), Ui.dp(c, 8))
        }
        fpsTv = metric()
        gpuTv = metric()
        batTv = metric()
        ramTv = metric()
        timeTv = Ui.text(c, "", 12f, Ui.DIM)
        val bar = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(fpsTv)
        bar.addView(gpuTv)
        bar.addView(batTv)
        bar.addView(ramTv)
        panel = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        root.addView(bar)
        root.addView(panel)

        val prefs = Store.prefs(c)
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("ox", Ui.dp(c, 8)).coerceAtLeast(0)
            y = prefs.getInt("oy", Ui.dp(c, 80)).coerceAtLeast(0)
        }
        root.setOnTouchListener(dragListener())
        wm.addView(root, lp)
    }

    private fun dragListener() = object : View.OnTouchListener {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = (startX + dx.toInt()).coerceAtLeast(0)
                        lp.y = (startY + dy.toInt()).coerceAtLeast(0)
                        wm.updateViewLayout(root, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        Store.prefs(this@OverlayService).edit()
                            .putInt("ox", lp.x).putInt("oy", lp.y).apply()
                    } else {
                        togglePanel()
                    }
                }
            }
            return true
        }
    }

    private fun togglePanel() {
        if (panel.visibility == View.VISIBLE) {
            panel.visibility = View.GONE
        } else {
            fillPanel()
            panel.visibility = View.VISIBLE
        }
    }

    // Panel multitasking: ikon app pilihan, tombol bersihkan RAM, tutup overlay.
    private fun fillPanel() {
        panel.removeAllViews()
        val c = this
        val pm = packageManager
        panel.addView(Ui.text(c, "MULTITASKING", 10f, Ui.DIM, true).apply {
            setPadding(0, Ui.dp(c, 8), 0, 0)
        })
        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        var count = 0
        for (p in Store.getList(c, Store.PINS)) {
            val launch = pm.getLaunchIntentForPackage(p) ?: continue
            val icon = try { pm.getApplicationIcon(p) } catch (e: Exception) { continue }
            val iv = ImageView(c).apply {
                setImageDrawable(icon)
                layoutParams = LinearLayout.LayoutParams(Ui.dp(c, 40), Ui.dp(c, 40)).apply {
                    marginEnd = Ui.dp(c, 8)
                    topMargin = Ui.dp(c, 6)
                }
                setOnClickListener {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launch)
                }
            }
            row.addView(iv)
            count++
        }
        if (count == 0) row.addView(Ui.text(c, "Belum ada app dipilih", 12f, Ui.DIM))
        panel.addView(row)
        panel.addView(timeTv.apply { setPadding(0, Ui.dp(c, 8), 0, 0) })
        panel.addView(Ui.button(c, "Bersihkan RAM", Ui.ACCENT) {
            val before = Booster.availMb(c)
            Booster.cleanRam(c) {
                Toast.makeText(
                    c, "RAM kosong: $before → ${Booster.availMb(c)} MB", Toast.LENGTH_SHORT
                ).show()
            }
        })
        panel.addView(Ui.button(c, "Tutup Overlay", Ui.ALT) { stopSelf() })
    }
}
