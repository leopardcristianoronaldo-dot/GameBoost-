package com.gamebooster

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ResolveInfo
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import java.io.File

object Booster {
    data class Batt(val temp: Float, val pct: Int, val charging: Boolean)

    fun launcherApps(ctx: Context): List<ResolveInfo> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
    }

    private fun mem(ctx: Context): ActivityManager.MemoryInfo {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    }

    fun availMb(ctx: Context): Long = mem(ctx).availMem / 1048576
    fun totalMb(ctx: Context): Long = mem(ctx).totalMem / 1048576

    fun battery(ctx: Context): Batt {
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        return Batt(temp, pct, charging)
    }

    private var gpuPath: String? = null
    private var gpuSearched = false

    /** Suhu GPU dari sysfs. Null jika tidak bisa dibaca di perangkat ini. */
    fun gpuTemp(): Float? {
        if (!gpuSearched) {
            gpuSearched = true
            try {
                val zones = File("/sys/class/thermal").listFiles()
                    ?.filter { it.name.startsWith("thermal_zone") } ?: emptyList()
                for (z in zones) {
                    try {
                        val type = File(z, "type").readText().trim().lowercase()
                        if (type.contains("gpu")) {
                            gpuPath = File(z, "temp").absolutePath
                            break
                        }
                    } catch (e: Exception) {
                    }
                }
            } catch (e: Exception) {
            }
        }
        val p = gpuPath ?: return null
        return try {
            val v = File(p).readText().trim().toFloat()
            val t = if (v > 1000f) v / 1000f else v
            if (t in 1f..150f) t else null
        } catch (e: Exception) {
            null
        }
    }

    /** Menutup proses latar belakang app lain (kecuali app multitasking dan yang di-keep). */
    fun cleanRam(ctx: Context, keep: Collection<String> = emptyList(), done: () -> Unit = {}) {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val skip = keep.toSet() + Store.getList(ctx, Store.PINS)
        for (app in launcherApps(ctx)) {
            val p = app.activityInfo.packageName
            if (p !in skip) am.killBackgroundProcesses(p)
        }
        Handler(Looper.getMainLooper()).postDelayed({ done() }, 700)
    }

    fun hasDnd(ctx: Context): Boolean =
        ctx.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

    /** on=true: aktifkan mode prioritas dan simpan kondisi lama. on=false: kembalikan kondisi lama. */
    fun setDnd(ctx: Context, on: Boolean) {
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (!nm.isNotificationPolicyAccessGranted) return
            val sp = Store.prefs(ctx)
            if (on) {
                if (!sp.contains(Store.DND_PREV)) {
                    sp.edit().putInt(Store.DND_PREV, nm.currentInterruptionFilter).apply()
                }
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            } else if (sp.contains(Store.DND_PREV)) {
                val prev = sp.getInt(Store.DND_PREV, NotificationManager.INTERRUPTION_FILTER_ALL)
                nm.setInterruptionFilter(
                    if (prev == NotificationManager.INTERRUPTION_FILTER_UNKNOWN)
                        NotificationManager.INTERRUPTION_FILTER_ALL else prev
                )
                sp.edit().remove(Store.DND_PREV).apply()
            }
        } catch (e: Exception) {
        }
    }
}
