package com.gamebooster

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.PlaybackParams

/** Mic -> ubah nada -> speaker/headset. Hanya berlaku di dalam app ini. */
class VoiceChanger {
    @Volatile private var running = false
    @Volatile var pitch = 1.0f
    val active: Boolean get() = running
    private var thread: Thread? = null

    @SuppressLint("MissingPermission")
    fun start() {
        if (running) return
        running = true
        thread = Thread {
            var rec: AudioRecord? = null
            var trk: AudioTrack? = null
            try {
                val rate = 16000
                val minIn = AudioRecord.getMinBufferSize(
                    rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                val minOut = AudioTrack.getMinBufferSize(
                    rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                rec = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minIn * 2
                )
                trk = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minOut * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                val buf = ShortArray(maxOf(minIn / 2, 1024))
                rec.startRecording()
                trk.play()
                var current = -1f
                while (running) {
                    if (current != pitch) {
                        current = pitch
                        try {
                            trk.playbackParams = PlaybackParams().setSpeed(1f).setPitch(current)
                        } catch (e: Exception) {
                        }
                    }
                    val n = rec.read(buf, 0, buf.size)
                    if (n > 0) trk.write(buf, 0, n)
                }
            } catch (e: Exception) {
            } finally {
                try { rec?.stop() } catch (e: Exception) { }
                rec?.release()
                try { trk?.stop() } catch (e: Exception) { }
                trk?.release()
                running = false
            }
        }.also { it.start() }
    }

    fun stop() {
        running = false
    }
}
