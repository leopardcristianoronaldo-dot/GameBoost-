package com.gamebooster

import android.content.Context
import android.content.SharedPreferences

object Store {
    const val GAMES = "games_v2"
    const val PINS = "pins_v2"
    const val AUTO = "auto_overlay"
    const val DND = "focus_dnd"
    const val DND_PREV = "dnd_prev"

    fun prefs(c: Context): SharedPreferences =
        c.getSharedPreferences("gb", Context.MODE_PRIVATE)

    fun getList(c: Context, key: String): MutableList<String> {
        val s = prefs(c).getString(key, "") ?: ""
        return if (s.isEmpty()) mutableListOf() else s.split(",").toMutableList()
    }

    fun putList(c: Context, key: String, v: List<String>) {
        prefs(c).edit().putString(key, v.distinct().joinToString(",")).apply()
    }

    fun flag(c: Context, key: String, def: Boolean): Boolean = prefs(c).getBoolean(key, def)

    fun setFlag(c: Context, key: String, v: Boolean) {
        prefs(c).edit().putBoolean(key, v).apply()
    }
}
