package com.gamebooster

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

/** Batang progres bulat. */
class BarView(c: Context) : View(c) {
    var fraction: Float = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var color: Int = Color.parseColor("#4F8CFF")
        set(v) {
            field = v
            invalidate()
        }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val r = height / 2f
        paint.color = Color.parseColor("#3A4050")
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, paint)
        if (fraction > 0f) {
            paint.color = color
            canvas.drawRoundRect(0f, 0f, width * fraction, height.toFloat(), r, r, paint)
        }
    }
}

class Tile(val root: LinearLayout, val value: TextView, val bar: BarView)

object Ui {
    val BG = Color.parseColor("#0E1014")
    val CARD = Color.parseColor("#1A1D24")
    val TEXT = Color.parseColor("#F2F4F8")
    val DIM = Color.parseColor("#8A93A6")
    val ACCENT = Color.parseColor("#4F8CFF")
    val ALT = Color.parseColor("#2A2F3A")
    val GOOD = Color.parseColor("#3DDC84")
    val WARN = Color.parseColor("#FFB020")
    val BAD = Color.parseColor("#FF5C5C")

    fun heat(t: Float): Int = if (t >= 43f) BAD else if (t >= 40f) WARN else GOOD

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun bg(color: Int, radius: Int, c: Context) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(c, radius).toFloat()
    }

    fun card(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = bg(CARD, 18, c)
        setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
            topMargin = dp(c, 12)
        }
    }

    fun text(c: Context, s: String, size: Float, color: Int = TEXT, bold: Boolean = false) =
        TextView(c).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun button(c: Context, s: String, color: Int = ACCENT, onClick: () -> Unit) =
        TextView(c).apply {
            text = s
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            background = bg(color, 12, c)
            setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12))
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                topMargin = dp(c, 8)
            }
            setOnClickListener { onClick() }
        }

    fun chip(c: Context, s: String, selected: Boolean, onClick: () -> Unit) =
        TextView(c).apply {
            text = s
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = bg(if (selected) ACCENT else ALT, 20, c)
            setPadding(dp(c, 6), dp(c, 10), dp(c, 6), dp(c, 10))
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply {
                marginEnd = dp(c, 6)
            }
            setOnClickListener { onClick() }
        }

    fun tile(c: Context, title: String): Tile {
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(ALT, 14, c)
            setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 12))
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply {
                marginStart = dp(c, 3)
                marginEnd = dp(c, 3)
            }
        }
        val value = text(c, "--", 18f, TEXT, true)
        val bar = BarView(c).apply {
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(c, 6)).apply {
                topMargin = dp(c, 8)
            }
        }
        root.addView(text(c, title, 10f, DIM, true))
        root.addView(value)
        root.addView(bar)
        return Tile(root, value, bar)
    }

    fun switchRow(
        c: Context, label: String, sub: String, initial: Boolean, onChange: (Boolean) -> Unit
    ): LinearLayout {
        val row = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                topMargin = dp(c, 10)
            }
        }
        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        }
        col.addView(text(c, label, 15f, TEXT, true))
        col.addView(text(c, sub, 12f, DIM))
        val sw = Switch(c)
        sw.isChecked = initial
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
        row.addView(col)
        row.addView(sw)
        return row
    }
}
