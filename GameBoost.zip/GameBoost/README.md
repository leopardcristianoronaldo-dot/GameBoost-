# GameBoost

Build APK tanpa Android Studio (cukup browser):
1. Buat repo baru di GitHub, upload semua isi folder ini (pastikan folder .github ikut).
2. Tab Actions -> "Build APK" -> tunggu hijau.
3. Unduh artifact "GameBoost-apk" -> ekstrak -> install app-debug.apk.

Atau buka folder ini di Android Studio, lalu Build > Build APK.
